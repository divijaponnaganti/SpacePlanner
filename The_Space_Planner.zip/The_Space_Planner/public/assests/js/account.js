// Retrieve user information from localStorage
const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));

// Check if user data is available in localStorage
if (loggedInUser) {
    // Display user details in the account page
    document.getElementById('full-name').textContent = loggedInUser.fullName;
    document.getElementById('email').textContent = loggedInUser.email;
    document.getElementById('phone').textContent = loggedInUser.phone;
    document.getElementById('address').textContent = loggedInUser.address || 'No address provided'; // Optional
} else {
    // Redirect to login page if not logged in
    window.location.href = 'login.html';
}

// Logout function to clear user data and redirect to login page
function logout() {
    localStorage.removeItem('loggedInUser'); // Clear user session data
    window.location.href = 'login.html';     // Redirect to login page
}
