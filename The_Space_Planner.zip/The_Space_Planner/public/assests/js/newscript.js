document.getElementById('register-form').addEventListener('submit', function (event) {
    // Prevent form submission until all validations pass
    event.preventDefault();

    // Fetch form values
    const firstName = document.getElementById('first-name').value.trim();
    const lastName = document.getElementById('last-name').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const phone = document.getElementById('register-phone').value.trim();
    const password = document.getElementById('register-password').value.trim();
    const termsAccepted = document.getElementById('terms').checked;

    // Validation flags
    let isValid = true;

    // Clear any previous error messages
    clearErrors();

    // Perform validations (as described before)
    // ... (same as before)

    // If all validations pass, store the user data
    if (isValid) {
        const newUser = {
            fullName: `${firstName} ${lastName}`,
            email,
            phone,
            password // For production, remember to hash passwords
        };

        // Store the newUser in localStorage under 'loggedInUser'
        localStorage.setItem('loggedInUser', JSON.stringify(newUser));

        // Log a message for debugging
        console.log('User registered:', newUser);

        // Redirect or show success message
        alert('Registration successful! Redirecting to account page...');
        window.location.href = 'account.html'; // Redirect to account page
    }
});
